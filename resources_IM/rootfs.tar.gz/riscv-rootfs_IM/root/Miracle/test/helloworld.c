#include <stdio.h>

void main(void)
{
    printf("helloworld!\n");
}
